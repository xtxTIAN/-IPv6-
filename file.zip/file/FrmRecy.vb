﻿Public Class FrmRecy
    Private Sub FrmRecy_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from rec_tbl", "rec_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        If ComboBox1.Text = "" Then
            MsgBox("必须选择回收状态！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        If DataGridView1.RowCount > 0 Then
            ID = CInt(DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value) + 1
        End If
        Dim comm As String = String.Format("insert into rec_tbl(ID,类型,名称,数量,回收入库时间,检查员,状态,备注) values({0},N'{1}',N'{2}',{3},'{4}',N'{5}',N'{6}',N'{7}')", {ID, TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), DateTimePicker1.Value, TextBox4.Text, ComboBox1.Text, TextBox6.Text})
        Fill(comm, "rec_tbl")
        DataGridView1.DataSource = Fill("select * from rec_tbl", "rec_tbl")
        DataGridView1.Columns(0).Visible = False
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        If DataGridView1.RowCount > 0 Then
            DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(2).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from rec_tbl where ID=" & ID, "rec_tbl")
            DataGridView1.DataSource = Fill("select * from rec_tbl", "rec_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择回收记录！无法修改！")
            Return
        End If
        If ComboBox1.Text = "" Then
            MsgBox("必须选择回收状态！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update rec_tbl set 类型=N'{0}',名称=N'{1}',数量={2},回收入库时间='{3}',检查员=N'{4}',状态=N'{5}',备注=N'{6}' where id={7}", {TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), DateTimePicker1.Value, TextBox4.Text, ComboBox1.Text, TextBox6.Text, ID})
        Fill(comm, "rec_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from rec_tbl", "rec_tbl")
        DataGridView1.SelectedRows(0).Selected = False
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count = 0 Then
            For Each t As TextBox In Controls.OfType(Of TextBox)
                t.ResetText()
            Next
            DateTimePicker1.Value = Now
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(1).Value
            TextBox2.Text = row.Cells(2).Value
            TextBox3.Text = row.Cells(3).Value
            DateTimePicker1.Value = row.Cells(4).Value
            TextBox4.Text = row.Cells(5).Value
            ComboBox1.Text = row.Cells(6).Value
            TextBox6.Text = row.Cells(7).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class