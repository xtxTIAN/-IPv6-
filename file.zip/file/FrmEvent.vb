﻿Public Class FrmEvent
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            t.ResetText()
        Next
        DateTimePicker1.Value = Now
    End Sub
    Private Sub FrmEvent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        Dim tb As DataTable = Fill("select max(id) from event_tbl", "event_tbl")
        If tb.Rows.Count > 0 Then
            Dim idcell As Object = tb.Rows(0).Item(0)
            If Not IsDBNull(idcell) Then
                ID = CInt(idcell) + 1
            End If
        End If
        Dim comm As String = String.Format("insert into event_tbl(ID,事件编号,发生时间,发生地点,灾害起因,受伤人数,死亡人数,损失情况,备注) values({0},N'{1}','{2}',N'{3}',N'{4}',{5},{6},N'{7}',N'{8}')", {ID, TextBox1.Text, DateTimePicker1.Value, TextBox2.Text, TextBox3.Text, Val(TextBox5.Text), TextBox7.Text, TextBox4.Text, TextBox6.Text})
        Fill(comm, "event_tbl")
        DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
        DataGridView1.Columns(0).Visible = False
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        If DataGridView1.RowCount > 0 Then
            DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(1).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from event_tbl where ID=" & ID, "event_tbl")
            DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择事件记录！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update event_tbl set 事件编号=N'{0}',发生时间='{1}',发生地点=N'{2}',灾害起因=N'{3}',受伤人数={4},死亡人数={5},损失情况=N'{6}',备注=N'{7}' where id={8}", {TextBox1.Text, DateTimePicker1.Value, TextBox2.Text, TextBox3.Text, Val(TextBox5.Text), TextBox7.Text, TextBox4.Text, TextBox6.Text, ID})
        Fill(comm, "event_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged, DataGridView1.CellClick
        Button1_Click(Nothing, Nothing)
        If DataGridView1.SelectedRows.Count = 0 Then
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(1).Value
            DateTimePicker1.Value = row.Cells(2).Value
            TextBox2.Text = row.Cells(3).Value
            TextBox3.Text = row.Cells(4).Value
            TextBox5.Text = row.Cells(5).Value
            TextBox7.Text = row.Cells(6).Value
            TextBox4.Text = row.Cells(7).Value
            TextBox6.Text = row.Cells(8).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class