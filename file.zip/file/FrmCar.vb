﻿Public Class FrmCar
    Private Sub FrmCar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from car_tbl", "car_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            t.ResetText()
        Next
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        Dim tb As DataTable = Fill("select max(id) from car_tbl", "car_tbl")
        If tb.Rows.Count > 0 Then
            Dim idcell As Object = tb.Rows(0).Item(0)
            If Not IsDBNull(idcell) Then
                ID = CInt(idcell) + 1
            End If
        End If
        Dim comm As String = String.Format("insert into car_tbl(ID,车组编号,车辆类型,车辆数量,所属单位,负责人,联系电话,备注) values({0},N'{1}',N'{2}',{3},N'{4}',N'{5}',N'{6}',N'{7}')", {ID, TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text, TextBox7.Text, TextBox6.Text})
        Fill(comm, "car_tbl")
        DataGridView1.DataSource = Fill("select * from car_tbl", "car_tbl")
        DataGridView1.Columns(0).Visible = False
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        If DataGridView1.RowCount > 0 Then
            DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(1).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from car_tbl where ID=" & ID, "car_tbl")
            DataGridView1.DataSource = Fill("select * from car_tbl", "car_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择车辆记录！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update car_tbl set 车组编号=N'{0}',车辆类型=N'{1}',车辆数量={2},所属单位=N'{3}',负责人=N'{4}',联系电话=N'{5}',备注=N'{6}' where id={7}", {TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text, TextBox7.Text, TextBox6.Text, ID})
        Fill(comm, "car_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from car_tbl", "car_tbl")
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged, DataGridView1.CellClick
        Button1_Click(Nothing, Nothing)
        If DataGridView1.SelectedRows.Count = 0 Then
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(1).Value
            TextBox2.Text = row.Cells(2).Value
            TextBox3.Text = row.Cells(3).Value
            TextBox4.Text = row.Cells(4).Value
            TextBox5.Text = row.Cells(5).Value
            TextBox7.Text = row.Cells(6).Value
            TextBox6.Text = row.Cells(7).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class