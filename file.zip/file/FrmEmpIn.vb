﻿Public Class FrmEmpIn

    Private Sub FrmEmpIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.DataSource = Fill("select * from empin_tbl", "empin_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = -1
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name <> "TextBox6" AndAlso t.Text = "" Then
                MsgBox("最少有一个值没有输入！")
                Return
            End If
        Next
        Dim ID As Integer
        If ComboBox1.FindStringExact(TextBox1.Text) > -1 Then
            MsgBox("该单位名称已存在！")
            Return
        End If
        If ComboBox1.Items.Count > 0 Then
            ID = DirectCast(ComboBox1.Items(ComboBox1.Items.Count - 1), DataRowView).Row.Field(Of Integer)("ID") + 1
        End If
        Dim comm As String = String.Format("insert into empIn_tbl(ID,单位名称,单位地址,人数,负责人,联系电话,备注) values({0},N'{1}',N'{2}',{3},N'{4}',N'{5}',N'{6}')", {ID, TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text, TextBox6.Text})
        Fill(comm, "empIn_tbl")
        ComboBox1.DataSource = Fill("select * from empin_tbl", "empin_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = ComboBox1.Items.Count - 1
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = -1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row As DataRow = DirectCast(ComboBox1.SelectedItem, DataRowView).Row
            TextBox1.Text = row.Field(Of String)("单位名称")
            TextBox2.Text = row.Field(Of String)("单位地址")
            TextBox3.Text = row.Field(Of Integer)("人数")
            TextBox4.Text = row.Field(Of String)("负责人")
            TextBox5.Text = row.Field(Of String)("联系电话")
            TextBox6.Text = row.Field(Of String)("备注")
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If ComboBox1.SelectedIndex = -1 Then Return
        Dim row As DataRow = DirectCast(ComboBox1.SelectedItem, DataRowView).Row
        Dim ID As Integer = row.Field(Of Integer)("ID")
        If MsgBox("是否删除单位""" & row.Field(Of String)("单位名称") & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from empIn_tbl where ID=" & ID, "empIn_tbl")
            ComboBox1.DataSource = Fill("select * from empin_tbl", "empin_tbl")
            ComboBox1.DisplayMember = "单位名称"
            ComboBox1.SelectedIndex = -1
            MsgBox("删除单位信息成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If ComboBox1.Text = "" Then
            MsgBox("没有选择单位！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name <> "TextBox6" AndAlso t.Text = "" Then
                MsgBox("最少有一个值没有输入！")
                Return
            End If
        Next
        Dim ID As Integer = DirectCast(ComboBox1.SelectedItem, DataRowView).Row.Field(Of Integer)("ID")
        Dim comm As String = String.Format("update empIn_tbl set 单位名称=N'{0}',单位地址=N'{1}',人数={2},负责人=N'{3}',联系电话=N'{4}',备注=N'{5}' where id={6}", {TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text, TextBox6.Text, ID})
        Fill(comm, "empIn_tbl")
        Dim index As Integer = ComboBox1.SelectedIndex
        ComboBox1.DataSource = Fill("select * from empin_tbl", "empin_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = index
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
End Class