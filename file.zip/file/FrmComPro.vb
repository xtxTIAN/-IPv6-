﻿Public Class FrmComPro
    Private Sub FrmComPro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.DataSource = Fill("select * from Third_tbl", "Third_tbl")
        ComboBox1.DisplayMember = "公司名称"
        ComboBox1.SelectedIndex = -1
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name <> "TextBox6" AndAlso t.Text = "" AndAlso t.Enabled Then
                MsgBox("最少有一个值没有输入！")
                Return
            End If
        Next
        Dim ID As Integer
        If ComboBox1.FindStringExact(TextBox2.Text) > -1 Then
            MsgBox("该公司名称已存在！")
            Return
        End If
        If ComboBox1.Items.Count > 0 Then
            ID = DirectCast(ComboBox1.Items(ComboBox1.Items.Count - 1), DataRowView).Row.Field(Of Integer)("ID") + 1
        End If
        Dim comm As String = String.Format("insert into Third_tbl(ID,公司编号,公司名称,公司地址,运营区域,资产规模,仓库面积,车辆类型,数量,负责人,联系电话,备注) values({0},N'{1}',N'{2}',N'{3}',N'{4}',{5},{6},N'{7}',{8},N'{9}',N'{10}',N'{11}')", {ID, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, Val(TextBox5.Text), Val(TextBox7.Text), TextBox8.Text, Val(TextBox9.Text), TextBox10.Text, TextBox11.Text, TextBox6.Text})
        Fill(comm, "Third_tbl")
        ComboBox1.DataSource = Fill("select * from Third_tbl", "Third_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = ComboBox1.Items.Count - 1
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = -1 Then
            For Each t As TextBox In Controls.OfType(Of TextBox)
                t.ResetText()
            Next
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row As DataRow = DirectCast(ComboBox1.SelectedItem, DataRowView).Row
            TextBox1.Text = row.Field(Of String)("公司编号")
            TextBox2.Text = row.Field(Of String)("公司名称")
            TextBox3.Text = row.Field(Of String)("公司地址")
            TextBox4.Text = row.Field(Of String)("运营区域")
            TextBox5.Text = row.Field(Of Decimal)("资产规模")
            TextBox7.Text = row.Field(Of Decimal)("仓库面积")
            TextBox8.Text = row.Field(Of String)("车辆类型")
            TextBox9.Text = row.Field(Of Integer)("数量")
            TextBox10.Text = row.Field(Of String)("负责人")
            TextBox11.Text = row.Field(Of String)("联系电话")
            TextBox12.Text = row.Field(Of String)("审核状态")
            TextBox6.Text = row.Field(Of String)("备注")
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If ComboBox1.SelectedIndex = -1 Then Return
        Dim row As DataRow = DirectCast(ComboBox1.SelectedItem, DataRowView).Row
        Dim ID As Integer = row.Field(Of Integer)("ID")
        Dim s As String = "该公司已审核通过！"
        If row.Field(Of String)("审核状态") <> "审核通过" Then s = ""
        Dim compro As String = row.Field(Of String)("公司名称") & """？" & s
        If MsgBox("是否删除公司""" & compro, MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from Third_tbl where ID=" & ID, "Third_tbl")
            ComboBox1.DataSource = Fill("select * from Third_tbl", "Third_tbl")
            ComboBox1.DisplayMember = "公司名称"
            ComboBox1.SelectedIndex = -1
            MsgBox("删除公司信息成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If ComboBox1.Text = "" Then
            MsgBox("没有选择公司！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name <> "TextBox6" AndAlso t.Text = "" AndAlso t.Enabled Then
                MsgBox("最少有一个值没有输入！")
                Return
            End If
        Next
        Dim row As DataRow = DirectCast(ComboBox1.SelectedItem, DataRowView).Row
        Dim ID As Integer = row.Field(Of Integer)("ID")
        Dim comm As String = String.Format("update Third_tbl set 公司编号=N'{0}',公司名称=N'{1}',公司地址=N'{2}',运营区域=N'{3}',资产规模={4},仓库面积={5},车辆类型=N'{6}',数量={7},负责人=N'{8}',联系电话=N'{9}',备注=N'{10}',审核状态=N'{11}' where id={12}", {TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, Val(TextBox5.Text), Val(TextBox7.Text), TextBox8.Text, Val(TextBox9.Text), TextBox10.Text, TextBox11.Text, TextBox6.Text, TextBox12.Text, ID})
        Fill(comm, "Third_tbl")
        Dim index As Integer = ComboBox1.SelectedIndex
        ComboBox1.DataSource = Fill("select * from Third_tbl", "Third_tbl")
        ComboBox1.DisplayMember = "公司名称"
        ComboBox1.SelectedIndex = index
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub

End Class