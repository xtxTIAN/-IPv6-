﻿Public Class FrmCarSel
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            t.ResetText()
        Next
        DateTimePicker1.Value = Now
    End Sub
    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If ComboBox1.SelectedIndex < 1 Then
            DataGridView1.DataSource = Fill("select * from car_tbl", "car_tbl")
        ElseIf KBoxFind.Text = "" Then
            MsgBox("请输入查询关键词！", MsgBoxStyle.Information)
        Else
            Dim comm As String = ""
            Select Case ComboBox1.SelectedIndex
                Case 1
                    comm = "select * from car_tbl where 所属单位=N'" & KBoxFind.Text & "'"
                Case 2
                    comm = "select * from car_tbl where 车辆类型=N'" & KBoxFind.Text & "'"
                Case 3
                    comm = "select * from car_tbl where 车辆数量=" & Val(KBoxFind.Text)
            End Select
            DataGridView1.DataSource = Fill(comm, "car_tbl")
        End If
        DataGridView1.Columns(0).Visible = False
    End Sub

    Private Sub FrmCarSel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView2.DataSource = Fill("select * from cardd_tbl", "cardd_tbl")
        DataGridView2.Columns(0).Visible = False
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name = "KBoxFind" OrElse t.Name <> "TextBox6" Then Continue For
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        Dim tb As DataTable = Fill("select max(id) from cardd_tbl", "cardd_tbl")
        If tb.Rows.Count > 0 Then
            Dim idcell As Object = tb.Rows(0).Item(0)
            If Not IsDBNull(idcell) Then
                ID = CInt(idcell) + 1
            End If
        End If
        Dim comm As String = String.Format("insert into cardd_tbl(ID,出车时间,车组编号,所属单位,车辆类型,车辆数量,联系电话,起点,目的地,内容,备注) values({0},'{1}',N'{2}',N'{3}',N'{4}',{5},N'{6}',N'{7}',N'{8}',N'{9}',N'{10}')", {ID, DateTimePicker1.Value, TextBox9.Text, TextBox1.Text, TextBox2.Text, TextBox5.Text, TextBox3.Text, TextBox4.Text, TextBox7.Text, TextBox8.Text, TextBox6.Text})
        Fill(comm, "cardd_tbl")
        DataGridView2.DataSource = Fill("select * from cardd_tbl", "cardd_tbl")
        DataGridView2.Columns(0).Visible = False
        If DataGridView2.SelectedRows.Count > 0 Then
            DataGridView2.SelectedRows(0).Selected = False
        End If
        If DataGridView2.RowCount > 0 Then
            DataGridView2.Rows(DataGridView2.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView2.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView2.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(1).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from cardd_tbl where ID=" & ID, "cardd_tbl")
            DataGridView2.DataSource = Fill("select * from cardd_tbl", "cardd_tbl")
            DataGridView2.Columns(0).Visible = False
            If DataGridView2.SelectedRows.Count > 0 Then
                DataGridView2.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView2.SelectedRows.Count < 1 Then
            MsgBox("没有选择出车记录！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Name = "KBoxFind" OrElse t.Name <> "TextBox6" Then Continue For
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView2.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update cardd_tbl set 出车时间='{0}',车组编号=N'{1}',所属单位=N'{2}',车辆类型=N'{3}',车辆数量={4},联系电话=N'{5}',起点=N'{6}',目的地=N'{7}',内容=N'{8}',备注=N'{9}' where id={10}", {DateTimePicker1.Value, TextBox9.Text, TextBox1.Text, TextBox2.Text, TextBox5.Text, TextBox3.Text, TextBox4.Text, TextBox7.Text, TextBox8.Text, TextBox6.Text, ID})
        Fill(comm, "cardd_tbl")
        Dim index As Integer = row.Index
        DataGridView2.DataSource = Fill("select * from cardd_tbl", "cardd_tbl")
        If DataGridView2.SelectedRows.Count > 0 Then
            DataGridView2.SelectedRows(0).Selected = False
        End If
        DataGridView2.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView2_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView2.SelectionChanged, DataGridView2.CellClick
        Button1_Click(Nothing, Nothing)
        If DataGridView2.SelectedRows.Count = 0 Then
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row = DataGridView2.SelectedRows(0)
            DateTimePicker1.Value = row.Cells(1).Value
            TextBox9.Text = row.Cells(2).Value
            TextBox1.Text = row.Cells(3).Value
            TextBox2.Text = row.Cells(4).Value
            TextBox5.Text = row.Cells(5).Value
            TextBox3.Text = row.Cells(6).Value
            TextBox4.Text = row.Cells(7).Value
            TextBox7.Text = row.Cells(8).Value
            TextBox8.Text = row.Cells(9).Value
            TextBox6.Text = row.Cells(10).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
    Private Sub DataGridView1_CellClick(sender As Object, e As EventArgs) Handles DataGridView1.CellClick, DataGridView1.SelectionChanged
        Button1_Click(Nothing, Nothing)
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row = DataGridView1.SelectedRows(0)
            TextBox9.Text = row.Cells(1).Value
            TextBox1.Text = row.Cells(4).Value
            TextBox2.Text = row.Cells(2).Value
            TextBox5.Text = row.Cells(3).Value
            TextBox3.Text = row.Cells(6).Value
        End If
    End Sub
End Class