﻿Public Class FrmCapFind
    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If ComboBox1.SelectedIndex < 1 Then
            DataGridView1.DataSource = Fill("select * from cap_tbl", "cap_tbl")
        ElseIf KBoxFind.Text = "" AndAlso ComboBox1.SelectedIndex <> 3 Then
            MsgBox("请输入查询关键词！", MsgBoxStyle.Information)
        Else
            Dim comm As String = ""
            Select Case ComboBox1.SelectedIndex
                Case 1
                    comm = "select * from cap_tbl where 类型=N'" & KBoxFind.Text & "'"
                Case 2
                    comm = "select * from cap_tbl where 对象=N'" & KBoxFind.Text & "'"
                Case 3
                    comm = "select * from cap_tbl where 时间 between '" & DateTimePicker1.Value & "' AND '" & DateTimePicker2.Value & "'"
            End Select
            DataGridView1.DataSource = Fill(comm, "cap_tbl")
        End If
        DataGridView1.Columns(0).Visible = False
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 3 Then '如果用户选择查询日期，则日期控件可以使用，输入查询词的文本框不可输入。
            DateTimePicker1.Visible = True
            DateTimePicker2.Visible = True
            KBoxFind.Visible = False
        Else '如果不，日期控件不允许使用，但文本框可以输入查询词。
            DateTimePicker1.Visible = False
            DateTimePicker2.Visible = False
            KBoxFind.Visible = True
        End If
    End Sub
End Class