﻿Public Class FrmShopOrd
    Private Sub FrmShopOrd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from shopbj_tbl", "shopbj_tbl")
        DataGridView1.Columns(0).Visible = False
        DataGridView2.DataSource = Fill("select * from shopord_tbl", "shopord_tbl")
        DataGridView2.Columns(0).Visible = False
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            t.ResetText()
        Next
        DateTimePicker1.Value = Now
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged, DataGridView1.CellClick
        Button1_Click(Nothing, Nothing)
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row = DataGridView1.SelectedRows(0)
            'TextBox1.Text = row.Cells(1).Value
            TextBox2.Text = row.Cells(2).Value
            TextBox3.Text = row.Cells(3).Value
            TextBox4.Text = row.Cells(4).Value
            TextBox5.Text = CInt(row.Cells(5).Value) * CInt(row.Cells(4).Value)
            TextBox9.Text = row.Cells(6).Value
            DateTimePicker1.Value = row.Cells(7).Value
            TextBox7.Text = row.Cells(8).Value
            TextBox8.Text = row.Cells(9).Value
            TextBox6.Text = row.Cells(10).Value
        End If
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        Dim tb As DataTable = Fill("select max(id) from shopord_tbl", "shopord_tbl")
        If tb.Rows.Count > 0 Then
            Dim idcell As Object = tb.Rows(0).Item(0)
            If Not IsDBNull(idcell) Then
                ID = CInt(idcell) + 1
            End If
        End If
        Dim comm As String = String.Format("insert into shopord_tbl(ID,订单编号,生成时间,类型,名称,数量,金额,交货地点,交货时间,供应商名称,联系电话,备注) values({0},N'{1}','{2}',N'{3}',N'{4}',{5},{6},N'{7}','{8}',N'{9}',N'{10}',N'{11}')", {ID, TextBox1.Text, Now, TextBox2.Text, TextBox3.Text, Val(TextBox4.Text), Val(TextBox5.Text), TextBox9.Text, DateTimePicker1.Value, TextBox7.Text, TextBox8.Text, TextBox6.Text})
        Fill(comm, "shopord_tbl")
        DataGridView2.DataSource = Fill("select * from shopord_tbl", "shopord_tbl")
        DataGridView2.Columns(0).Visible = False
        If DataGridView2.SelectedRows.Count > 0 Then
            DataGridView2.SelectedRows(0).Selected = False
        End If
        If DataGridView2.RowCount > 0 Then
            DataGridView2.Rows(DataGridView2.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView2.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView2.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(1).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from shopord_tbl where ID=" & ID, "shopord_tbl")
            DataGridView2.DataSource = Fill("select * from shopord_tbl", "shopord_tbl")
            DataGridView2.Columns(0).Visible = False
            If DataGridView2.SelectedRows.Count > 0 Then
                DataGridView2.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub
    Private Sub DataGridView2_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView2.SelectionChanged, DataGridView2.CellClick
        If DataGridView2.SelectedRows.Count = 0 Then
            'For Each t As TextBox In Controls.OfType(Of TextBox)
            '    t.ResetText()
            'Next
            'DateTimePicker1.Value = Now
            BtnDel.Enabled = False
        Else
            'Dim row = DataGridView2.SelectedRows(0)
            'TextBox1.Text = row.Cells(1).Value
            'TextBox2.Text = row.Cells(2).Value
            'TextBox3.Text = row.Cells(3).Value
            'TextBox4.Text = row.Cells(4).Value
            'TextBox5.Text = row.Cells(5).Value
            'TextBox9.Text = row.Cells(6).Value
            'DateTimePicker1.Value = row.Cells(7).Value
            'TextBox7.Text = row.Cells(8).Value
            'TextBox8.Text = row.Cells(9).Value
            'TextBox6.Text = row.Cells(10).Value
            BtnDel.Enabled = True
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            CheckBox1.Text = "显示全部"
            Dim min As DataTable = Fill("select id,min(报价) from shopbj_tbl group by 名称,报价,ID", "shopbj_tbl")
            Dim ids As New List(Of String)
            For Each r As DataRow In min.Rows
                If Not IsDBNull(r.Item(0)) Then
                    ids.Add("ID=" & r.Item(0).ToString)
                End If
            Next
            DataGridView1.DataSource = Fill("select * from shopbj_tbl where (" & Join(ids.ToArray, " OR ") & ")", "shopbj_tbl")
            DataGridView1.Columns(0).Visible = False
        Else
            CheckBox1.Text = "筛选最优报价"
            DataGridView1.DataSource = Fill("select * from shopbj_tbl", "shopbj_tbl")
            DataGridView1.Columns(0).Visible = False
        End If
    End Sub
End Class