﻿Public Class FrmIOFind
    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        Dim comm As String = ""
        If ComboBox1.SelectedIndex < 1 Then
            Select Case ComboBox2.SelectedIndex
                Case 0
                    comm = "select * from inout_tbl"
                Case 1
                    comm = "select * from inout_tbl where 操作=N'入库'"
                Case 2
                    comm = "select * from inout_tbl where 操作=N'出库'"
            End Select
            DataGridView1.DataSource = Fill(comm, "inout_tbl")
        ElseIf KBoxFind.Text = "" AndAlso ComboBox1.SelectedIndex <> 4 Then
            MsgBox("请输入查询关键词！", MsgBoxStyle.Information)
        Else
            Select Case ComboBox2.SelectedIndex
                Case 0
                    Select Case ComboBox1.SelectedIndex
                        Case 1
                            comm = "select * from inout_tbl where 类型=N'" & KBoxFind.Text & "'"
                        Case 2
                            comm = "select * from inout_tbl where 名称=N'" & KBoxFind.Text & "'"
                        Case 3
                            comm = "select * from inout_tbl where 库位=N'" & KBoxFind.Text & "'"
                        Case 4
                            comm = "select * from inout_tbl where 出入库时间 between '" & DateTimePicker1.Value & "' AND '" & DateTimePicker2.Value & "'"
                    End Select
                Case Else
                    Dim InOut As String = "入库"
                    If ComboBox2.SelectedIndex = 1 Then
                    Else
                        InOut = "出库"
                    End If
                    Select Case ComboBox1.SelectedIndex
                        Case 1
                            comm = "select * from inout_tbl where (类型=N'" & KBoxFind.Text & "' AND 操作=N'" & InOut & "')"
                        Case 2
                            comm = "select * from inout_tbl where (名称=N'" & KBoxFind.Text & "' AND 操作=N'" & InOut & "')"
                        Case 3
                            comm = "select * from inout_tbl where (库位=N'" & KBoxFind.Text & "' AND 操作=N'" & InOut & "')"
                        Case 4
                            comm = "select * from inout_tbl where ((出入库时间 between '" & DateTimePicker1.Value & "' AND '" & DateTimePicker2.Value & "') AND 操作=N'" & InOut & "')"
                    End Select
            End Select
            DataGridView1.DataSource = Fill(comm, "inout_tbl")
        End If
        DataGridView1.Columns(0).Visible = False
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 4 Then '如果用户选择查询日期，则日期控件可以使用，输入查询词的文本框不可输入。
            DateTimePicker1.Visible = True
            DateTimePicker2.Visible = True
            KBoxFind.Visible = False
        Else '如果不，日期控件不允许使用，但文本框可以输入查询词。
            DateTimePicker1.Visible = False
            DateTimePicker2.Visible = False
            KBoxFind.Visible = True
        End If
    End Sub

    Private Sub FrmIOFind_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox2.SelectedIndex = 0
    End Sub
End Class