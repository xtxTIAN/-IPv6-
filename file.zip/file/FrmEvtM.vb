﻿Public Class FrmEvtM
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FrmHisFind.ShowDialog()
    End Sub

    Private Sub FrmEvtM_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged, DataGridView1.CellClick
        If DataGridView1.SelectedRows.Count = 0 Then
            ComboBox1.SelectedIndex = -1
            'Button2.Enabled = False
            ComboBox1.Enabled = False
        Else
            Dim row = DataGridView1.SelectedRows(0)
            If Not IsDBNull(row.Cells(9).Value) Then
                ComboBox1.SelectedIndex = ComboBox1.FindStringExact(row.Cells(9).Value)
                'Button2.Enabled = True
            Else
                ComboBox1.SelectedIndex = -1
                'Button2.Enabled = False
            End If
            ComboBox1.Enabled = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim id As Integer = CInt(DataGridView1.SelectedRows(0).Cells(0).Value)
            Fill("update event_tbl set 等级预案=" & Val(ComboBox1.Text) & " where id=" & id, "应急等级")
            Dim lvObj As Object = DataGridView1.SelectedRows(0).Cells(9).Value
            Dim lv As Integer
            If Not IsDBNull(lvObj) Then
                lv = CInt(lvObj)
            End If
            If lv = Val(ComboBox1.Text) Then Return
            Dim index As Integer = DataGridView1.SelectedRows(0).Index
            DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.RowCount > 0 Then
                DataGridView1.Rows(0).Selected = False
                DataGridView1.Rows(index).Selected = True
            End If
            If lv > Val(ComboBox1.Text) Then
                MsgBox("应急等级已降低！")
            Else
                MsgBox("应急等级已提升！")
            End If
        Else
            MsgBox("必须选择一个事件！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = -1 Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
    End Sub
End Class