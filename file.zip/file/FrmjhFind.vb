﻿Public Class FrmjhFind
    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If ComboBox1.SelectedIndex < 1 Then
            DataGridView1.DataSource = Fill("select * from shopjh_tbl", "shopjh_tbl")
        ElseIf KBoxFind.Text = "" Then
            MsgBox("请输入搜索词！")
            Return
        Else
            Dim comm As String = ""
            comm = "select * from shopjh_tbl where " & ComboBox1.Text & "=N'" & KBoxFind.Text & "'"
            DataGridView1.DataSource = Fill(comm, "shopjh_tbl")
        End If
        DataGridView1.Columns(0).Visible = False
    End Sub
End Class