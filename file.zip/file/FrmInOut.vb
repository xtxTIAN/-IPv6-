﻿Public Class FrmInOut
    Public InOut As String
    Private Sub FrmInOut_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from inout_tbl where 操作=N'" & InOut & "'", "inout_tbl")
        DataGridView1.Columns(0).Visible = False
        DataGridView1.Columns(1).Visible = False
        Text = "公路边坡应急物流管理系统 - " & InOut & "管理"
        Label4.Text = InOut & "时间："
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        Dim tb As DataTable = Fill("select max(id) from inout_tbl", "inout_tbl")
        If tb.Rows.Count > 0 Then
            Dim obj As Object = tb.Rows(0).ItemArray(0)
            If Not IsDBNull(obj) Then
                ID = CInt(obj) + 1
            End If
        End If
        Dim comm As String = String.Format("insert into inout_tbl(ID,操作,类型,名称,数量,出入库时间,库位,装载车辆牌照,操作员,备注) values({0},N'{1}',N'{2}',N'{3}',{4},'{5}',N'{6}',N'{7}',N'{8}',N'{9}')", {ID, InOut, TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), DateTimePicker1.Value, TextBox4.Text, TextBox5.Text, TextBox7.Text, TextBox6.Text})
        Fill(comm, "inout_tbl")
        DataGridView1.DataSource = Fill("select * from inout_tbl where 操作=N'" & InOut & "'", "inout_tbl")
        DataGridView1.Columns(0).Visible = False
        DataGridView1.Columns(1).Visible = False
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        If DataGridView1.RowCount > 0 Then
            DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(3).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from inout_tbl where ID=" & ID, "inout_tbl")
            DataGridView1.DataSource = Fill("select * from inout_tbl where 操作=N'" & InOut & "'", "inout_tbl")
            DataGridView1.Columns(0).Visible = False
            DataGridView1.Columns(1).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择" & InOut & "记录！无法修改！")
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" AndAlso t.Name <> "TextBox6" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update inout_tbl set 操作=N'{0}',类型=N'{1}',名称=N'{2}',数量={3},出入库时间='{4}',库位=N'{5}',装载车辆牌照=N'{6}',操作员=N'{7}',备注=N'{8}' where id={9}", {InOut, TextBox1.Text, TextBox2.Text, Val(TextBox3.Text), DateTimePicker1.Value, TextBox4.Text, TextBox5.Text, TextBox7.Text, TextBox6.Text, ID})
        Fill(comm, "inout_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from inout_tbl where 操作=N'" & InOut & "'", "inout_tbl")
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count = 0 Then
            For Each t As TextBox In Controls.OfType(Of TextBox)
                t.ResetText()
            Next
            DateTimePicker1.Value = Now
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
        Else
            Dim row = DataGridView1.SelectedRows(0)
            TextBox1.Text = row.Cells(2).Value
            TextBox2.Text = row.Cells(3).Value
            TextBox3.Text = row.Cells(4).Value
            DateTimePicker1.Value = row.Cells(5).Value
            TextBox4.Text = row.Cells(6).Value
            TextBox5.Text = row.Cells(7).Value
            TextBox7.Text = row.Cells(8).Value
            TextBox6.Text = row.Cells(9).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class