﻿Module Module1
    Public data As String = "Data Source=2001:250:3401:40a0:f964:1731:be88:1598;Initial Catalog=应急data;Persist Security Info=True;User ID=sa;Password=123456"
    ''' <summary>本次登录的用户名。</summary>
    Public UserName As String
    ''' <summary>将数据刷新到数据库，如果是读，将返回结果记录表。</summary>
    ''' <param name="command"></param>
    ''' <param name="tablename"></param>
    Public Function Fill(command As String, tablename As String) As DataTable
        Dim table As DataTable = Nothing
        Using kcData As New SqlClient.SqlConnection(data)
            kcData.Open()
            Using adp As New SqlClient.SqlDataAdapter(command, kcData)
                Using ds As New DataSet
                    adp.Fill(ds, tablename)
                    If ds.Tables.Count > 0 Then table = ds.Tables(0)
                End Using
            End Using
            kcData.Close()
        End Using
        'Using kcData As New OleDb.OleDbConnection(data)
        '    kcData.Open()
        '    Using adp As New OleDb.OleDbDataAdapter(command, kcData)
        '        Using ds As New DataSet
        '            adp.Fill(ds, tablename)
        '            If ds.Tables.Count > 0 Then table = ds.Tables(0)
        '        End Using
        '    End Using
        '    kcData.Close()
        'End Using
        Return table
    End Function


End Module

