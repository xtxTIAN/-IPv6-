﻿Public Class FrmLogin
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FrmReg.Show()
        Close()
    End Sub 'reg

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Dim tb As DataTable = Fill("Select 密码 FROM user_tbl WHERE 用户=N'" & TextUser.Text & "'", "user_tbl")
        If tb.Rows.Count > 0 Then
            If Trim(tb.Rows(0).Field(Of String)("密码")) = TextPass.Text Then
                UserName = TextUser.Text
                FrmMain.Text = "公路边坡应急物流管理系统 - 欢迎您！（" & TextUser.Text & ")"
                FrmMain.Show()
                Close()
            Else
                MsgBox("密码错误！请重新输入！")
            End If
        Else
            MsgBox("用户名错误！请重新输入！")
        End If
    End Sub 'log

    Private Sub TextUser_TextChanged(sender As Object, e As EventArgs) Handles TextUser.TextChanged, TextPass.TextChanged
        BtnLogin.Enabled = Not (TextUser.Text = "" Or TextPass.Text = "")
    End Sub
End Class