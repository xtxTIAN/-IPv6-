﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.用户UToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.注销RToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.修改账户ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.退出XToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急事件管理EToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急事件录入WToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急事件匹配预案PToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急信息管理IToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急预案录入修改查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.历史应急信息查询HToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急单位管理SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.单位档案录入AToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.单位调度录入DToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.单位培训录入PToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急运输管理AToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出车记录OToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.车辆选择SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急采购管理SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购计划单JToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购报价单BToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.采购订单TToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急库存SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.入库录入IToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.出库录入OToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.统计查询FToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急回收ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.回收录入查询IToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.维修报损录入查询BToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急资金AToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.收入支出记录SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.收支统计查询FToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急发布管理RToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应急处理情况录入QToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.需求信息发布查询HToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.第三方物流公司管理TToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.公司录入CToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.公司审核SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.帮助HToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.关于程序AToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.用户UToolStripMenuItem, Me.应急事件管理EToolStripMenuItem, Me.应急信息管理IToolStripMenuItem, Me.应急单位管理SToolStripMenuItem, Me.应急运输管理AToolStripMenuItem, Me.应急采购管理SToolStripMenuItem, Me.应急库存SToolStripMenuItem, Me.应急回收ToolStripMenuItem, Me.应急资金AToolStripMenuItem, Me.应急发布管理RToolStripMenuItem, Me.第三方物流公司管理TToolStripMenuItem, Me.帮助HToolStripMenuItem})
        Me.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(828, 46)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        '用户UToolStripMenuItem
        '
        Me.用户UToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.注销RToolStripMenuItem, Me.修改账户ToolStripMenuItem, Me.退出XToolStripMenuItem})
        Me.用户UToolStripMenuItem.Name = "用户UToolStripMenuItem"
        Me.用户UToolStripMenuItem.Size = New System.Drawing.Size(61, 21)
        Me.用户UToolStripMenuItem.Text = "用户(&U)"
        '
        '注销RToolStripMenuItem
        '
        Me.注销RToolStripMenuItem.Name = "注销RToolStripMenuItem"
        Me.注销RToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.注销RToolStripMenuItem.Text = "注销(&R)"
        '
        '修改账户ToolStripMenuItem
        '
        Me.修改账户ToolStripMenuItem.Name = "修改账户ToolStripMenuItem"
        Me.修改账户ToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.修改账户ToolStripMenuItem.Text = "修改账户(&E)"
        '
        '退出XToolStripMenuItem
        '
        Me.退出XToolStripMenuItem.Name = "退出XToolStripMenuItem"
        Me.退出XToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.退出XToolStripMenuItem.Text = "退出(&X)"
        '
        '应急事件管理EToolStripMenuItem
        '
        Me.应急事件管理EToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.应急事件录入WToolStripMenuItem, Me.应急事件匹配预案PToolStripMenuItem})
        Me.应急事件管理EToolStripMenuItem.Name = "应急事件管理EToolStripMenuItem"
        Me.应急事件管理EToolStripMenuItem.Size = New System.Drawing.Size(108, 21)
        Me.应急事件管理EToolStripMenuItem.Text = "应急事件管理(&V)"
        '
        '应急事件录入WToolStripMenuItem
        '
        Me.应急事件录入WToolStripMenuItem.Name = "应急事件录入WToolStripMenuItem"
        Me.应急事件录入WToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.应急事件录入WToolStripMenuItem.Text = "应急事件录入(&W)"
        '
        '应急事件匹配预案PToolStripMenuItem
        '
        Me.应急事件匹配预案PToolStripMenuItem.Name = "应急事件匹配预案PToolStripMenuItem"
        Me.应急事件匹配预案PToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.应急事件匹配预案PToolStripMenuItem.Text = "应急事件匹配预案(&P)"
        '
        '应急信息管理IToolStripMenuItem
        '
        Me.应急信息管理IToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.应急预案录入修改查询ToolStripMenuItem, Me.历史应急信息查询HToolStripMenuItem})
        Me.应急信息管理IToolStripMenuItem.Name = "应急信息管理IToolStripMenuItem"
        Me.应急信息管理IToolStripMenuItem.Size = New System.Drawing.Size(104, 21)
        Me.应急信息管理IToolStripMenuItem.Text = "应急信息管理(&I)"
        '
        '应急预案录入修改查询ToolStripMenuItem
        '
        Me.应急预案录入修改查询ToolStripMenuItem.Name = "应急预案录入修改查询ToolStripMenuItem"
        Me.应急预案录入修改查询ToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.应急预案录入修改查询ToolStripMenuItem.Text = "应急预案管理(Y)"
        '
        '历史应急信息查询HToolStripMenuItem
        '
        Me.历史应急信息查询HToolStripMenuItem.Name = "历史应急信息查询HToolStripMenuItem"
        Me.历史应急信息查询HToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.历史应急信息查询HToolStripMenuItem.Text = "历史应急信息查询(&H)"
        '
        '应急单位管理SToolStripMenuItem
        '
        Me.应急单位管理SToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.单位档案录入AToolStripMenuItem, Me.单位调度录入DToolStripMenuItem, Me.单位培训录入PToolStripMenuItem})
        Me.应急单位管理SToolStripMenuItem.Name = "应急单位管理SToolStripMenuItem"
        Me.应急单位管理SToolStripMenuItem.Size = New System.Drawing.Size(107, 21)
        Me.应急单位管理SToolStripMenuItem.Text = "应急单位管理(&E)"
        '
        '单位档案录入AToolStripMenuItem
        '
        Me.单位档案录入AToolStripMenuItem.Name = "单位档案录入AToolStripMenuItem"
        Me.单位档案录入AToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.单位档案录入AToolStripMenuItem.Text = "单位档案录入(&A)"
        '
        '单位调度录入DToolStripMenuItem
        '
        Me.单位调度录入DToolStripMenuItem.Name = "单位调度录入DToolStripMenuItem"
        Me.单位调度录入DToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.单位调度录入DToolStripMenuItem.Text = "单位调度录入(&D)"
        '
        '单位培训录入PToolStripMenuItem
        '
        Me.单位培训录入PToolStripMenuItem.Name = "单位培训录入PToolStripMenuItem"
        Me.单位培训录入PToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.单位培训录入PToolStripMenuItem.Text = "单位培训录入(&P)"
        '
        '应急运输管理AToolStripMenuItem
        '
        Me.应急运输管理AToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.出车记录OToolStripMenuItem, Me.车辆选择SToolStripMenuItem})
        Me.应急运输管理AToolStripMenuItem.Name = "应急运输管理AToolStripMenuItem"
        Me.应急运输管理AToolStripMenuItem.Size = New System.Drawing.Size(107, 21)
        Me.应急运输管理AToolStripMenuItem.Text = "应急运输管理(&T)"
        '
        '出车记录OToolStripMenuItem
        '
        Me.出车记录OToolStripMenuItem.Name = "出车记录OToolStripMenuItem"
        Me.出车记录OToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.出车记录OToolStripMenuItem.Text = "车辆管理(&C)"
        '
        '车辆选择SToolStripMenuItem
        '
        Me.车辆选择SToolStripMenuItem.Name = "车辆选择SToolStripMenuItem"
        Me.车辆选择SToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.车辆选择SToolStripMenuItem.Text = "车辆选择(&S)"
        '
        '应急采购管理SToolStripMenuItem
        '
        Me.应急采购管理SToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.采购计划单JToolStripMenuItem, Me.采购报价单BToolStripMenuItem, Me.采购订单TToolStripMenuItem})
        Me.应急采购管理SToolStripMenuItem.Name = "应急采购管理SToolStripMenuItem"
        Me.应急采购管理SToolStripMenuItem.Size = New System.Drawing.Size(112, 21)
        Me.应急采购管理SToolStripMenuItem.Text = "应急采购管理(&M)"
        '
        '采购计划单JToolStripMenuItem
        '
        Me.采购计划单JToolStripMenuItem.Name = "采购计划单JToolStripMenuItem"
        Me.采购计划单JToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.采购计划单JToolStripMenuItem.Text = "采购计划单(&J)"
        '
        '采购报价单BToolStripMenuItem
        '
        Me.采购报价单BToolStripMenuItem.Name = "采购报价单BToolStripMenuItem"
        Me.采购报价单BToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.采购报价单BToolStripMenuItem.Text = "采购报价单(&B)"
        '
        '采购订单TToolStripMenuItem
        '
        Me.采购订单TToolStripMenuItem.Name = "采购订单TToolStripMenuItem"
        Me.采购订单TToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.采购订单TToolStripMenuItem.Text = "采购订单(&T)"
        '
        '应急库存SToolStripMenuItem
        '
        Me.应急库存SToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.入库录入IToolStripMenuItem, Me.出库录入OToolStripMenuItem, Me.统计查询FToolStripMenuItem})
        Me.应急库存SToolStripMenuItem.Name = "应急库存SToolStripMenuItem"
        Me.应急库存SToolStripMenuItem.Size = New System.Drawing.Size(107, 21)
        Me.应急库存SToolStripMenuItem.Text = "应急库存管理(&S)"
        '
        '入库录入IToolStripMenuItem
        '
        Me.入库录入IToolStripMenuItem.Name = "入库录入IToolStripMenuItem"
        Me.入库录入IToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.入库录入IToolStripMenuItem.Text = "入库录入(&I)"
        '
        '出库录入OToolStripMenuItem
        '
        Me.出库录入OToolStripMenuItem.Name = "出库录入OToolStripMenuItem"
        Me.出库录入OToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.出库录入OToolStripMenuItem.Text = "出库录入(&O)"
        '
        '统计查询FToolStripMenuItem
        '
        Me.统计查询FToolStripMenuItem.Name = "统计查询FToolStripMenuItem"
        Me.统计查询FToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.统计查询FToolStripMenuItem.Text = "统计查询(&F)"
        '
        '应急回收ToolStripMenuItem
        '
        Me.应急回收ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.回收录入查询IToolStripMenuItem, Me.维修报损录入查询BToolStripMenuItem})
        Me.应急回收ToolStripMenuItem.Name = "应急回收ToolStripMenuItem"
        Me.应急回收ToolStripMenuItem.Size = New System.Drawing.Size(108, 21)
        Me.应急回收ToolStripMenuItem.Text = "应急回收管理(&R)"
        '
        '回收录入查询IToolStripMenuItem
        '
        Me.回收录入查询IToolStripMenuItem.Name = "回收录入查询IToolStripMenuItem"
        Me.回收录入查询IToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.回收录入查询IToolStripMenuItem.Text = "回收录入查询(&I)"
        '
        '维修报损录入查询BToolStripMenuItem
        '
        Me.维修报损录入查询BToolStripMenuItem.Name = "维修报损录入查询BToolStripMenuItem"
        Me.维修报损录入查询BToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.维修报损录入查询BToolStripMenuItem.Text = "维修报损录入查询(&B)"
        '
        '应急资金AToolStripMenuItem
        '
        Me.应急资金AToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.收入支出记录SToolStripMenuItem, Me.收支统计查询FToolStripMenuItem})
        Me.应急资金AToolStripMenuItem.Name = "应急资金AToolStripMenuItem"
        Me.应急资金AToolStripMenuItem.Size = New System.Drawing.Size(108, 21)
        Me.应急资金AToolStripMenuItem.Text = "应急资金管理(&A)"
        '
        '收入支出记录SToolStripMenuItem
        '
        Me.收入支出记录SToolStripMenuItem.Name = "收入支出记录SToolStripMenuItem"
        Me.收入支出记录SToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.收入支出记录SToolStripMenuItem.Text = "收入支出记录(&S)"
        '
        '收支统计查询FToolStripMenuItem
        '
        Me.收支统计查询FToolStripMenuItem.Name = "收支统计查询FToolStripMenuItem"
        Me.收支统计查询FToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.收支统计查询FToolStripMenuItem.Text = "收支统计查询(&F)"
        '
        '应急发布管理RToolStripMenuItem
        '
        Me.应急发布管理RToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.应急处理情况录入QToolStripMenuItem, Me.需求信息发布查询HToolStripMenuItem})
        Me.应急发布管理RToolStripMenuItem.Name = "应急发布管理RToolStripMenuItem"
        Me.应急发布管理RToolStripMenuItem.Size = New System.Drawing.Size(107, 21)
        Me.应急发布管理RToolStripMenuItem.Text = "应急发布管理(&P)"
        '
        '应急处理情况录入QToolStripMenuItem
        '
        Me.应急处理情况录入QToolStripMenuItem.Name = "应急处理情况录入QToolStripMenuItem"
        Me.应急处理情况录入QToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.应急处理情况录入QToolStripMenuItem.Text = "应急处理情况录入(&Q)"
        '
        '需求信息发布查询HToolStripMenuItem
        '
        Me.需求信息发布查询HToolStripMenuItem.Name = "需求信息发布查询HToolStripMenuItem"
        Me.需求信息发布查询HToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.需求信息发布查询HToolStripMenuItem.Text = "需求信息发布查询"
        '
        '第三方物流公司管理TToolStripMenuItem
        '
        Me.第三方物流公司管理TToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.公司录入CToolStripMenuItem, Me.公司审核SToolStripMenuItem})
        Me.第三方物流公司管理TToolStripMenuItem.Name = "第三方物流公司管理TToolStripMenuItem"
        Me.第三方物流公司管理TToolStripMenuItem.Size = New System.Drawing.Size(144, 21)
        Me.第三方物流公司管理TToolStripMenuItem.Text = "第三方物流公司管理(&C)"
        '
        '公司录入CToolStripMenuItem
        '
        Me.公司录入CToolStripMenuItem.Name = "公司录入CToolStripMenuItem"
        Me.公司录入CToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.公司录入CToolStripMenuItem.Text = "公司录入(&C)"
        '
        '公司审核SToolStripMenuItem
        '
        Me.公司审核SToolStripMenuItem.Name = "公司审核SToolStripMenuItem"
        Me.公司审核SToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.公司审核SToolStripMenuItem.Text = "公司审核(&S)"
        '
        '帮助HToolStripMenuItem
        '
        Me.帮助HToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.关于程序AToolStripMenuItem})
        Me.帮助HToolStripMenuItem.Name = "帮助HToolStripMenuItem"
        Me.帮助HToolStripMenuItem.Size = New System.Drawing.Size(61, 21)
        Me.帮助HToolStripMenuItem.Text = "帮助(&H)"
        '
        '关于程序AToolStripMenuItem
        '
        Me.关于程序AToolStripMenuItem.Name = "关于程序AToolStripMenuItem"
        Me.关于程序AToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.关于程序AToolStripMenuItem.Text = "关于程序(&A)"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("微软雅黑", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(60, 99)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(727, 67)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "公路边坡应急物流管理系统"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("微软雅黑", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(284, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(272, 34)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "（Verson 1.0）"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("宋体", 21.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Green
        Me.Label3.Location = New System.Drawing.Point(239, 253)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(376, 28)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "（请操作菜单管理相关功能）"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(828, 433)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmMain"
        Me.Text = "公路边坡应急物流管理系统"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents 用户UToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 注销RToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 修改账户ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 退出XToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急事件管理EToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急事件录入WToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急事件匹配预案PToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急信息管理IToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急预案录入修改查询ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 历史应急信息查询HToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急单位管理SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急运输管理AToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急采购管理SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急库存SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急回收ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急资金AToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急发布管理RToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 第三方物流公司管理TToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 单位档案录入AToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 单位调度录入DToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 单位培训录入PToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 出车记录OToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 车辆选择SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 采购计划单JToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 采购报价单BToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 采购订单TToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 入库录入IToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 出库录入OToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 统计查询FToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 回收录入查询IToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 维修报损录入查询BToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 收入支出记录SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 收支统计查询FToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 应急处理情况录入QToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 需求信息发布查询HToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 公司录入CToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 公司审核SToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 帮助HToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 关于程序AToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    'Friend WithEvents ToolStripContainer1 As ToolStripContainer
End Class
