﻿Public Class FrmMain
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub 退出XToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 退出XToolStripMenuItem.Click
        End
    End Sub

    Private Sub 修改账户ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 修改账户ToolStripMenuItem.Click
        FrmEidtUser.TextBox1.Text = UserName
        FrmEidtUser.ShowDialog()
    End Sub

    Private Sub 注销RToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 注销RToolStripMenuItem.Click
        FrmLogin.Show()
        Close()
    End Sub

    Private Sub 关于程序AToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 关于程序AToolStripMenuItem.Click
        MsgBox("公路边坡应急物流管理系统！授权给所有用户，版权所有。", MsgBoxStyle.Information, "公路边坡应急物流管理系统")
    End Sub

    Private Sub 单位档案录入AToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 单位档案录入AToolStripMenuItem.Click
        FrmEmpIn.ShowDialog()
    End Sub

    Private Sub 单位调度录入DToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 单位调度录入DToolStripMenuItem.Click
        FrmEmpDD.ShowDialog()
    End Sub

    Private Sub 单位培训录入PToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 单位培训录入PToolStripMenuItem.Click
        FrmEmpPX.ShowDialog()
    End Sub

    Private Sub 公司录入CToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 公司录入CToolStripMenuItem.Click
        FrmComPro.ShowDialog()
    End Sub

    Private Sub 公司审核SToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 公司审核SToolStripMenuItem.Click
        FrmComRev.ShowDialog()
    End Sub

    Private Sub 回收录入查询IToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 回收录入查询IToolStripMenuItem.Click
        FrmRecy.ShowDialog()
    End Sub

    Private Sub 维修报损录入查询BToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 维修报损录入查询BToolStripMenuItem.Click
        FrmWX.ShowDialog()
    End Sub

    Private Sub 收入支出记录SToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 收入支出记录SToolStripMenuItem.Click
        FrmCap.ShowDialog()
    End Sub

    Private Sub 收支统计查询FToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 收支统计查询FToolStripMenuItem.Click
        FrmCapFind.ShowDialog()
    End Sub

    Private Sub 入库录入IToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 入库录入IToolStripMenuItem.Click
        FrmInOut.InOut = "入库"
        FrmInOut.ShowDialog()
    End Sub

    Private Sub 出库录入OToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 出库录入OToolStripMenuItem.Click
        FrmInOut.InOut = "出库"
        FrmInOut.ShowDialog()
    End Sub

    Private Sub 统计查询FToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 统计查询FToolStripMenuItem.Click
        FrmIOFind.ShowDialog()
    End Sub

    Private Sub 采购计划单JToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 采购计划单JToolStripMenuItem.Click
        FrmShopjh.ShowDialog()
    End Sub

    Private Sub 采购报价单BToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 采购报价单BToolStripMenuItem.Click
        FrmShopbj.ShowDialog()
    End Sub

    Private Sub 采购订单TToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 采购订单TToolStripMenuItem.Click
        FrmShopOrd.ShowDialog()
    End Sub

    Private Sub 应急事件录入WToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 应急事件录入WToolStripMenuItem.Click
        FrmEvent.ShowDialog()
    End Sub

    Private Sub 应急预案录入修改查询ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 应急预案录入修改查询ToolStripMenuItem.Click
        FrmCase.ShowDialog()
    End Sub

    Private Sub 应急处理情况录入QToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 应急处理情况录入QToolStripMenuItem.Click
        FrmEvthd.ShowDialog()
    End Sub

    Private Sub 历史应急信息查询HToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 历史应急信息查询HToolStripMenuItem.Click
        FrmHisFind.ShowDialog()
    End Sub

    Private Sub 应急事件匹配预案PToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 应急事件匹配预案PToolStripMenuItem.Click
        FrmEvtM.ShowDialog()
    End Sub

    Private Sub 需求信息发布查询HToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 需求信息发布查询HToolStripMenuItem.Click
        FrmjhFind.ShowDialog()
    End Sub

    Private Sub 出车记录OToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 出车记录OToolStripMenuItem.Click
        FrmCar.ShowDialog()
    End Sub

    Private Sub 车辆选择SToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 车辆选择SToolStripMenuItem.Click
        FrmCarSel.ShowDialog()
    End Sub
End Class
