﻿Public Class FrmEidtUser
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FrmMain.Show()
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'edit
        If TextBox2.Text = "" Then
            MsgBox("旧密码为空！", MsgBoxStyle.Exclamation)
            Return
        End If
        Dim pass As String = Trim(TextBox3.Text)
        If pass = "" OrElse TextBox4.Text = "" Then
            MsgBox("请输入或重复输入1-10位新密码！", MsgBoxStyle.Exclamation)
            Return
        ElseIf pass <> TextBox4.Text Then
            MsgBox("两次输入的密码不一致！新密码应该为1-10位。", MsgBoxStyle.Exclamation)
            Return
        End If
        Dim tb As DataTable = Fill("Select * FROM user_tbl WHERE 用户=N'" & TextBox1.Text & "'", "user_tbl")
        If tb.Rows.Count > 0 Then
            Dim id As Integer = tb.Rows(0).Field(Of Integer)("ID")
            If Trim(tb.Rows(0).Field(Of String)("密码")) = TextBox2.Text Then
                Fill(String.Format("update user_tbl set 用户=N'{0}',密码=N'{1}' where id={2}", {TextBox1.Text, pass, id}), "user_tbl")
                MsgBox("修改密码成功！请重新登录！", MsgBoxStyle.Information)
                FrmLogin.Show()
                FrmMain.Close()
                Close()
            Else
                MsgBox("旧密码错误，请检查！", MsgBoxStyle.Information)
            End If
        Else
            MsgBox("用户名错误，修改密码失败！", MsgBoxStyle.Information)
        End If
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox2.Text = "" Then
            MsgBox("旧密码为空！", MsgBoxStyle.Exclamation)
            Return
        End If
        If MsgBox("确认删除用户：" & TextBox1.Text & "？", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Return
        Dim tb As DataTable = Fill("Select * FROM user_tbl WHERE 用户=N'" & TextBox1.Text & "'", "user_tbl")
        If tb.Rows.Count > 0 Then
            Dim id As Integer = tb.Rows(0).Field(Of Integer)("ID")
            If Trim(tb.Rows(0).Field(Of String)("密码")) = TextBox2.Text Then
                Fill("DELETE from user_tbl where id=" & id, "user_tbl")
                MsgBox("删除用户成功！", MsgBoxStyle.Information)
                FrmLogin.Show()
                FrmMain.Close()
                Close()
            Else
                MsgBox("密码错误，请检查！", MsgBoxStyle.Information)
            End If
        Else
            MsgBox("用户名错误，删除未成功！", MsgBoxStyle.Information)
        End If
    End Sub
End Class