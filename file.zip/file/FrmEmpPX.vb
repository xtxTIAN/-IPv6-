﻿Public Class FrmEmpPX
    Private Sub FrmEmpIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.DataSource = Fill("select * from empIN_tbl", "empIN_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = -1
        DataGridView1.DataSource = Fill("select * from empPX_tbl", "empPX_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        If ComboBox1.Text = "" Then
            MsgBox("请选择要培训的单位！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        If DataGridView1.RowCount > 0 Then
            ID = CInt(DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value) + 1
        End If
        Dim comm As String = String.Format("insert into empPX_tbl(ID,培训起始时间,培训地点,培训单位,人数,培训内容) values({0},'{1}',N'{2}',N'{3}',{4},N'{5}')", {ID, DateTimePicker1.Value, TextBox3.Text, ComboBox1.Text, Val(TextBox4.Text), TextBox5.Text})
        Fill(comm, "empPX_tbl")
        DataGridView1.DataSource = Fill("select * from empPX_tbl", "empPX_tbl")
        DataGridView1.Columns(0).Visible = False
        DataGridView1.SelectedRows(0).Selected = False
        DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(2).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from empPX_tbl where ID=" & ID, "empPX_tbl")
            DataGridView1.DataSource = Fill("select * from empPX_tbl", "empPX_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择培训记录！无法修改！")
            Return
        End If
        If ComboBox1.Text = "" Then
            MsgBox("必须选择培训单位！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update empPX_tbl set 培训起始时间='{0}',培训地点=N'{1}',培训单位=N'{2}',人数={3},培训内容=N'{4}' where id={5}", {DateTimePicker1.Value, TextBox3.Text, ComboBox1.Text, Val(TextBox4.Text), TextBox5.Text, ID})
        Fill(comm, "empPX_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from empPX_tbl", "empPX_tbl")
        DataGridView1.SelectedRows(0).Selected = False
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count = 0 Then
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            DateTimePicker1.Value = Now
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
            ComboBox1.Text = ""
        Else
            Dim row = DataGridView1.SelectedRows(0)
            DateTimePicker1.Value = row.Cells(1).Value
            TextBox3.Text = row.Cells(2).Value
            ComboBox1.SelectedIndex = ComboBox1.FindString(row.Cells(3).Value)
            TextBox4.Text = row.Cells(4).Value
            TextBox5.Text = row.Cells(5).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class