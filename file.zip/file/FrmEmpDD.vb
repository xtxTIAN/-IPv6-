﻿Public Class FrmEmpDD
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        If ComboBox1.Text = "" Then
            MsgBox("请选择要调度的单位！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim ID As Integer
        If DataGridView1.RowCount > 0 Then
            ID = CInt(DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value) + 1
        End If
        Dim comm As String = String.Format("insert into empDd_tbl(ID,时间,单位名称,人数,目的地,乘坐车辆牌照) values({0},'{1}',N'{2}',{3},N'{4}',N'{5}')", {ID, DateTimePicker1.Value, ComboBox1.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text})
        Fill(comm, "empDd_tbl")
        DataGridView1.DataSource = Fill("select * from empDd_tbl", "empDd_tbl")
        DataGridView1.Columns(0).Visible = False
        If DataGridView1.SelectedRows.Count > 0 Then
            DataGridView1.SelectedRows(0).Selected = False
        End If
        If DataGridView1.RowCount > 0 Then
            DataGridView1.Rows(DataGridView1.RowCount - 1).Selected = True
        End If
        MsgBox("添加成功！", MsgBoxStyle.Information)
    End Sub

    Private Sub FrmEmpIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.DataSource = Fill("select * from empIN_tbl", "empIN_tbl")
        ComboBox1.DisplayMember = "单位名称"
        ComboBox1.SelectedIndex = -1
        DataGridView1.DataSource = Fill("select * from empDd_tbl", "empDd_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub

    Private Sub BtnDel_Click(sender As Object, e As EventArgs) Handles BtnDel.Click
        If DataGridView1.SelectedRows.Count < 1 Then Return
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        If MsgBox("是否删除记录""" & row.Cells(2).Value & """？", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Fill("delete from empDd_tbl where ID=" & ID, "empDd_tbl")
            DataGridView1.DataSource = Fill("select * from empDd_tbl", "empDd_tbl")
            DataGridView1.Columns(0).Visible = False
            If DataGridView1.SelectedRows.Count > 0 Then
                DataGridView1.SelectedRows(0).Selected = False
            End If
            MsgBox("删除记录成功！", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click
        If DataGridView1.SelectedRows.Count < 1 Then
            MsgBox("没有选择记录！无法修改！")
            Return
        End If
        If ComboBox1.Text = "" Then
            MsgBox("必须选择可调度单位！", MsgBoxStyle.Information)
            Return
        End If
        For Each t As TextBox In Controls.OfType(Of TextBox)
            If t.Text = "" Then
                MsgBox("最少有一个值没有输入！", MsgBoxStyle.Information)
                Return
            End If
        Next
        Dim row = DataGridView1.SelectedRows(0)
        Dim ID As Integer = row.Cells(0).Value
        Dim comm As String = String.Format("update empDd_tbl set 时间='{0}',单位名称=N'{1}',人数={2},目的地=N'{3}',乘坐车辆牌照=N'{4}' where id={5}", {DateTimePicker1.Value, ComboBox1.Text, Val(TextBox3.Text), TextBox4.Text, TextBox5.Text, ID})
        Fill(comm, "empDd_tbl")
        Dim index As Integer = row.Index
        DataGridView1.DataSource = Fill("select * from empDd_tbl", "empDd_tbl")
        DataGridView1.SelectedRows(0).Selected = False
        DataGridView1.Rows(index).Selected = True
        MsgBox("修改成功！", MsgBoxStyle.Information)
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count = 0 Then
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            DateTimePicker1.Value = Now
            BtnEdit.Enabled = False
            BtnDel.Enabled = False
            ComboBox1.Text = ""
        Else
            Dim row = DataGridView1.SelectedRows(0)
            DateTimePicker1.Value = row.Cells(1).Value
            ComboBox1.SelectedIndex = ComboBox1.FindString(row.Cells(2).Value)
            TextBox3.Text = row.Cells(3).Value
            TextBox4.Text = row.Cells(4).Value
            TextBox5.Text = row.Cells(5).Value
            BtnEdit.Enabled = True
            BtnDel.Enabled = True
        End If
    End Sub
End Class