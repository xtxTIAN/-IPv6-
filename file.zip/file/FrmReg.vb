﻿Public Class FrmReg
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FrmLogin.Show()
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim user As String = Trim(TextBox1.Text)
        Dim pass As String = Trim(TextBox2.Text)
        If pass = "" OrElse TextBox3.Text = "" Then
            MsgBox("请输入或重复输入1-10位密码！", MsgBoxStyle.Exclamation)
            Return
        ElseIf pass <> TextBox3.Text Then
            MsgBox("两次输入的密码不一致！新密码应该为1-10位。", MsgBoxStyle.Exclamation)
            Return
        End If
        Dim tb As DataTable = Fill("Select 密码 FROM user_tbl WHERE 用户=N'" & TextBox1.Text & "'", "user_tbl")
        If tb.Rows.Count > 0 Then
            MsgBox("该用户已注册！", MsgBoxStyle.Information)
        Else
            tb = Fill("select max(id) from user_tbl", "user_tbl")
            Dim id As Integer
            If Not IsDBNull(tb.Rows(0).Item(0)) Then
                id = CInt(tb.Rows(0).Item(0)) + 1
            End If
            Fill(String.Format("insert into user_tbl(ID,用户,密码) values({2},N'{0}',N'{1}')", {user, pass, id}), "user_tbl")
            MsgBox("注册成功！请重新登录本系统！"， MsgBoxStyle.Information)
            FrmLogin.Show()
            Close()
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Button1.Enabled = Not TextBox1.Text = ""
    End Sub
End Class