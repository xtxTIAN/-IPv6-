﻿Public Class FrmComRev
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            DataGridView1.DataSource = Fill("select * from third_tbl", "third_tbl")
            CheckBox1.Text = "显示未审核"
        Else
            DataGridView1.DataSource = Fill("select * from third_tbl where 审核状态=''", "third_tbl")
            CheckBox1.Text = "显示全部"
        End If
    End Sub
    Private Sub FrmComRev_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = Fill("select * from third_tbl where 审核状态=''", "third_tbl")
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim ID As Integer = CInt(DataGridView1.SelectedRows(0).Cells(0).Value)
            Fill("update third_tbl set 审核状态=N'通过' where ID=" & ID, "third_tbl")
            Label2.ResetText()
            MsgBox("已通过审核！")
            CheckBox1_CheckedChanged(Nothing, Nothing)
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim ID As Integer = CInt(DataGridView1.SelectedRows(0).Cells(0).Value)
            Fill("update third_tbl set 审核状态=N'拒绝' where ID=" & ID, "third_tbl")
            Label2.ResetText()
            MsgBox("已拒绝通过！")
            CheckBox1_CheckedChanged(Nothing, Nothing)
        End If
    End Sub 'R
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim val As Object = DataGridView1.SelectedRows(0).Cells(12).Value
            If Not IsDBNull(val) Then
                Label2.Text = CStr(val)
            Else
                Label2.Text = ""
            End If
        Else
            Label2.ResetText()
        End If
    End Sub
End Class