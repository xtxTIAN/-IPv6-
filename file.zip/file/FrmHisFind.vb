﻿Public Class FrmHisFind
    Private Sub FrmHisFind_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'DateTimePicker1.Value = Now.Date
        'DateTimePicker2.Value = Now.Date
        Dim b = My.Application.OpenForms

    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged, DataGridView1.CellClick
        DataGridView2.DataSource = Nothing
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
            Dim ID As String = row.Cells(1).Value
            DataGridView2.DataSource = Fill("select * from evthd_tbl where 事件编号=N'" & ID & "'", "evthd_tbl")
            DataGridView2.Columns(0).Visible = False
        End If
    End Sub
    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        If ComboBox1.SelectedIndex < 1 Then
            DataGridView1.DataSource = Fill("select * from event_tbl", "event_tbl")
        ElseIf KBoxFind.Text = "" AndAlso ComboBox1.SelectedIndex <> 2 Then
            MsgBox("请输入搜索词！")
            Return
        Else
            Dim comm As String = ""
            Select Case ComboBox1.SelectedIndex
                Case 1
                    comm = "select * from event_tbl where 事件编号=N'" & KBoxFind.Text & "'"
                Case 2
                    comm = "select * from event_tbl where 发生时间 between '" & DateTimePicker1.Value & "' AND '" & DateTimePicker2.Value & "'"
                Case 3
                    comm = "select * from event_tbl where 发生地点 Like N'%" & KBoxFind.Text & "%'"
                Case 4
                    comm = "select * from event_tbl where 受伤人数=" & Val(KBoxFind.Text)
                Case 5
                    comm = "select * from event_tbl where 死亡人数=" & Val(KBoxFind.Text)
                Case 6
                    comm = "select * from event_tbl where 灾害起因 Like N'%" & KBoxFind.Text & "%'"
                Case 7
                    comm = "select * from event_tbl where 损失情况 Like N'%" & KBoxFind.Text & "%'"
                Case Else
                    comm = "select * from event_tbl where 备注 Like N'%" & KBoxFind.Text & "%'"
            End Select
            DataGridView1.DataSource = Fill(comm, "event_tbl")
        End If
        DataGridView1.Columns(0).Visible = False
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "发生时间" Then
            DateTimePicker1.Visible = True
            DateTimePicker2.Visible = True
            KBoxFind.Visible = False
        Else
            DateTimePicker1.Visible = False
            DateTimePicker2.Visible = False
            KBoxFind.Visible = True
        End If
    End Sub
    '    全部
    '事件编号
    '发生时间
    '发生地点
    '受伤人数
    '死亡人数
    '灾害起因
    '损失情况
End Class